package pruebas;

public class HolaMundo {

	public static void main(String[] args) {
		// Imprimir Hola GIT
		System.out.println("Hola GiT!!");
	}

}
